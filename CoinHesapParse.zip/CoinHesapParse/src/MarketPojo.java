
public class MarketPojo {
   private String tip;
   private double fiyat;
   private double miktar;
   private double toplam;
   private double gerceklesenMiktar;
   private double gerceklesenToplam;
   private String market;
   private String tarih;

    public String getTip() {
        return tip;
    }

    public void setTip(String tip) {
        this.tip = tip;
    }

    public double getFiyat() {
        return fiyat;
    }

    public void setFiyat(double fiyat) {
        this.fiyat = fiyat;
    }

    public double getMiktar() {
        return miktar;
    }

    public void setMiktar(double miktar) {
        this.miktar = miktar;
    }

    public double getToplam() {
        return toplam;
    }

    public void setToplam(double toplam) {
        this.toplam = toplam;
    }

    public double getGerceklesenMiktar() {
        return gerceklesenMiktar;
    }

    public void setGerceklesenMiktar(double gerceklesenMiktar) {
        this.gerceklesenMiktar = gerceklesenMiktar;
    }

    public double getGerceklesenToplam() {
        return gerceklesenToplam;
    }

    public void setGerceklesenToplam(double gerceklesenToplam) {
        this.gerceklesenToplam = gerceklesenToplam;
    }

    public String getMarket() {
        return market;
    }

    public void setMarket(String market) {
        this.market = market;
    }

    public String getTarih() {
        return tarih;
    }

    public void setTarih(String tarih) {
        this.tarih = tarih;
    }
   
   
}
